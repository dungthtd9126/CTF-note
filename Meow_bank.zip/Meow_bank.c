#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/random.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdbool.h>

typedef struct account account;
typedef struct account* p_account;

typedef struct account
{
    unsigned int balance;
    unsigned int last_used_attempt;
    unsigned int is_admin;
    unsigned int is_logged;

    char username[0x100];
    char password[0x100];
    char cmt[0x50];
} account;

struct account acc;
unsigned long long real_balance = 0x20000;

account processing;

static void init(void)
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    memset(&acc, 0, sizeof(account));
}

static void vault_access()
{
    puts("You have accessed the bank's secret vault!");
    system("/bin/sh"); // <-- Get here to get flag :))
    exit(0);
}

static void banner(void)
{
    puts(
        "========================================\n"
        "|                                      |\n"
        "|      ____    _    _   _ _  __        |\n"
        "|     | __ )  / \\  | \\ | | |/ /        |\n"
        "|     |  _ \\ / _ \\ |  \\| | ' /         |\n"
        "|     | |_) / ___ \\| |\\  | . \\         |\n"
        "|     |____/_/   \\_\\_| \\_|_|\\_\\        |\n"
        "|                                      |\n"
        "|               B A N K                |\n"
        "|        Secure Banking System         |\n"
        "|                                      |\n"
        "========================================\n"
    );
}

static void menu(void)
{
    puts(
        "========================================\n"
        "|              [ BANK ]                |\n"
        "|======================================|\n"
        "| [1] Check balance                    |\n"
        "| [2] Deposit                          |\n"
        "| [3] Transfer                         |\n"
        "| [4] Widthdraw                        |\n"
        "| [5] Log out                          |\n"
        "| [6] Exit                             |\n"
        "========================================\n"
    );
    printf(">> ");
}

static void menu_acc_auth(void)
{
    puts(
        "========================================\n"
        "|              [ BANK ]                |\n"
        "|======================================|\n"
        "| [1] Register                         |\n"
        "| [2] Login                            |\n"
        "| [3] Exit                             |\n"
        "========================================\n"
    );
    printf(">> ");
}

#define CRED_DIR "./cred"
#define PATH_SIZE 512

bool register_user(p_account cur)
{      
    int n = 0;
    printf("Username: ");
    n = read(0, cur->username, sizeof(cur->username) - 1);
    if (n <= 0) return -1;
    cur->username[n] = '\0';
    cur->username[strcspn(cur->username, "\r\n")] = '\0';

    printf("Password: ");
    n = read(0, cur->password, sizeof(cur->password) - 1);
    if (n <= 0) return -1;
    cur->password[n] = '\0';
    cur->password[strcspn(cur->password, "\r\n")] = '\0';

    printf("Initialize balance: ");
    scanf("%u", &cur->balance);

    char filepath[PATH_SIZE];
    
    if (mkdir(CRED_DIR, 0755) == -1 && errno != EEXIST)
    {
        perror("mkdir");
        return false;
    }
    int ret = snprintf(filepath, sizeof(filepath), "%s/%s.txt", CRED_DIR, cur->username);

    if (ret < 0 || (size_t)ret >= sizeof(filepath))
    {
        fprintf(stderr, "Path too long\n");
        return false;
    }
    if (access(filepath, F_OK) == 0)
    {
        printf("Username already exists!\n");
        return false;
    }
    FILE *fp = fopen(filepath, "w");
    if (fp == NULL)
    {
        perror("fopen");
        return false;
    }

    fprintf(fp, "%s\n", cur->username);
    fprintf(fp, "%s\n", cur->password);
    fprintf(fp, "%u\n", cur->balance);
    fclose(fp);

    printf("Registered: %s\n", filepath);
    return true;
}

int login_user(const char *username, const char *password)
{
    char filepath[512];
    snprintf(filepath, sizeof(filepath), "./cred/%s.txt", username);
    FILE *fp = fopen(filepath, "r");
    if (!fp)
    {
        printf("User not found\n");
        return false;
    }

    char file_username[0x100];
    char file_password[0x100];
    unsigned int balance = 0;
    unsigned int admin = 0;
    memset(&file_username, 0, sizeof(file_username));
    memset(&file_password, 0, sizeof(file_password));
    int ret = fscanf(fp, "%256s %256s %u %u", file_username, file_password, &balance, &admin);
    if ( ret != 3 && ret !=4 )
    {
        fclose(fp);
        printf("Corrupted account file\n");
        return false;
    }

    fclose(fp);

    if (strcmp(file_username, username) != 0 || strcmp(file_password, password) != 0)
    {
        printf("Invalid credentials\n");
        return false;
    }

    strcpy(acc.username, username);
    strcpy(acc.password, password);
    acc.balance = balance;
    acc.is_admin = admin;
    acc.is_logged = 1;

    printf("Login successful!\n");
    printf("Balance: %u\n", balance);

    return true;
}


static bool account_auth(void)
{
    if(acc.is_logged) return true;

    unsigned int choice;
    ssize_t n;
    p_account cur = malloc(sizeof(account));

    while(true)
    {
        memset(cur, 0, sizeof(account));
        menu_acc_auth();

        if (scanf("%u", &choice) != 1)
        {
            perror("scanf");
            return false;
        }

        switch(choice)
        {
            case 1:
                if(!register_user(cur))
                {
                    puts("Failed to register account!!!");
                    break;
                }
                break;

            case 2:
                printf("Username: ");
                n = read(0, cur->username, sizeof(cur->username) - 1);
                if (n <= 0) 
                    return -1;
                cur->username[n] = '\0';
                cur->username[strcspn(cur->username, "\r\n")] = '\0';

                printf("Password: ");
                n = read(0, cur->password, sizeof(cur->password) - 1);
                if (n <= 0) 
                    return -1;
                cur->password[n] = '\0';
                cur->password[strcspn(cur->password, "\r\n")] = '\0';

                if(login_user(cur->username, cur->password))
                {
                    puts("Login successful!");
                    return true;
                }
                else
                {
                    puts("Wrong username or password!!!");
                    break;
                }
                break;

            case 3:
                puts("Bye bye, see you soon!!!");
                exit(0);

            default:
                puts("Invalid choice!");
                break;
        }
    }
}

static bool logout()
{
    char filepath[PATH_SIZE];

    int ret = snprintf(filepath, sizeof(filepath), "%s/%s.txt", CRED_DIR, acc.username);

    if (ret < 0 || (size_t)ret >= sizeof(filepath))
    {
        fprintf(stderr, "Path too long\n");
        return false;
    }

    FILE *fp = fopen(filepath, "w");
    if (fp == NULL)
    {
        perror("fopen");
        return false;
    }

    fprintf(fp, "%s\n", acc.username);
    fprintf(fp, "%s\n", acc.password);
    fprintf(fp, "%u\n", acc.balance);
    fprintf(fp, "%79s\n", acc.cmt);
    fclose(fp);

    memset(&acc, 0, sizeof(account));

    puts("Logged out!");
    return true;
}

static void check_balance()
{
    printf("Your current balance: %u\n", acc.balance);
    printf("Last used amount: %u\n", acc.last_used_attempt);
    printf("Your note: %s\n", acc.cmt);
}


static bool transfer()
{
    char filepath[512];
    char username_dst[0x100];
    p_account dst = malloc(sizeof(account));

    if(dst == NULL)
    {
        printf("Failed to allocate memory for destination account\n");
        return false;
    }

    printf("Enter the username for beneficiary account: ");
    int n = read(0, &username_dst, (sizeof(username_dst)) - 1);
    if (n <= 0) return false;
    username_dst[n] = '\0';
    username_dst[strcspn(username_dst, "\r\n")] = '\0';

    if(!strcmp(username_dst, acc.username))
    {
        printf("Beneficiary account must be another account not your account!\n");
        return false;
    }

    snprintf(filepath, sizeof(filepath), "./cred/%s.txt", username_dst);

    FILE *fp = fopen(filepath, "r");
    if (!fp)
    {
        printf("User not found\n");
        free(dst);

        return false;
    }

    if (fscanf(fp, "%255s %255s %u", dst->username, dst->password, &dst->balance) != 3)
    {
        fclose(fp);
        free(dst);

        printf("Corrupted account file\n");
        return false;
    }

    printf("Enter the transfer amount: ");
    scanf("%u", &acc.last_used_attempt);

    if (acc.last_used_attempt <= 0 || acc.last_used_attempt > acc.balance)
    {
        puts("Insufficient balance or transfer amount!");
        fclose(fp);
        free(dst);
        return false;
    }

    printf("Enter transfer message: ");
    n = read(0, acc.cmt, sizeof(acc.cmt) -1);
    acc.cmt[n] = 0;
    
    acc.balance -= acc.last_used_attempt;
    dst->balance += acc.last_used_attempt;


    fprintf(fp, "%s\n", dst->username);
    fprintf(fp, "%s\n", dst->password);
    fprintf(fp, "%u\n", dst->balance);
    fprintf(fp, "%79s\n", dst->cmt);

    fclose(fp);
    snprintf(filepath, sizeof(filepath), "./cred/%s.txt", acc.username);

    fp = fopen(filepath, "r");
    fprintf(fp, "%s\n", acc.username);
    fprintf(fp, "%s\n", acc.password);
    fprintf(fp, "%u\n", acc.balance);
    fprintf(fp, "%79s\n", acc.cmt);

    fclose(fp);
    free(dst);

    puts("Transaction successful!");
    printf("Transaction amount: %u\n", acc.last_used_attempt);
    printf("Message: %s\n", acc.cmt);

    return true;
}

static bool deposit()
{
    char filepath[512];

    snprintf(filepath, sizeof(filepath), "./cred/%s.txt", acc.username);
    FILE *fp = fopen(filepath, "w");
    if (!fp)
    {
        printf("User not found\n");
        return false;
    }

    printf("Enter the deposit amount: ");
    /*
                  Nhìn dưới   
                    |
                    |
                    v
    Nhìn phải  --> Bọ :0 <--- Nhìn trái
                    |
                    |
                    |
                    v
    */
    scanf("%llu", &acc.last_used_attempt); // unsigned long long  - 8 byte

/*
typedef struct account
{
    unsigned int balance;
    unsigned int last_used_attempt; - 4 byte
    unsigned int is_admin;          - 4 byte
    unsigned int is_logged;
...
}
*/

    if (acc.last_used_attempt > real_balance)
    {
        puts("Invalid amount!");
        fclose(fp);
        return false;
    }

    acc.balance += acc.last_used_attempt;
    real_balance -= acc.last_used_attempt;

    fprintf(fp, "%s\n", acc.username);
    fprintf(fp, "%s\n", acc.password);
    fprintf(fp, "%u\n", acc.balance);
    fprintf(fp, "%79s\n", acc.cmt);

    fclose(fp);

    puts("Deposit successful!");
    return true;
}

static bool widthdraw()
{   
    char filepath[512];

    snprintf(filepath, sizeof(filepath), "./cred/%s.txt", acc.username);
    FILE *fp = fopen(filepath, "w");
    if (!fp)
    {
        printf("User not found\n");
        return false;
    }

    printf("Enter the amount you want to widthdraw: ");

    scanf("%u", &acc.last_used_attempt);

    if (acc.last_used_attempt > acc.balance)
    {
        puts("Invalid amount!");
        fclose(fp);
        return false;
    }

    acc.balance -= acc.last_used_attempt;
    real_balance += acc.last_used_attempt;

    fprintf(fp, "%u\n", acc.balance);

    fclose(fp);

    return true;
}

static void vuln(void)
{
    unsigned int choice;
    while(true)
    {
        if(!account_auth())
        {
            exit(1);
        }
        while(acc.is_logged)
        {
            if (acc.is_admin == 0x776f656d) // Chuỗi "byte": b'meow' : p32(0x776f656d)
            {
                vault_access(); // <-- Get here to win :))
            }
            menu();
            if (scanf("%u", &choice) != 1)
            {
                perror("scanf");
                return;
            }
            switch(choice)
            {
                case 1:
                    check_balance();
                    break;
                case 2:
                    deposit(); // <-- bug is here :3
                    break;
                case 3:
                    transfer(); // Please create atleast 2 accounts to use this :((
                    break;
                case 4:
                    widthdraw();
                    break;
                case 5:
                    logout();
                    break;
                case 6:
                    puts("Bye bye, see you soon!!!");
                    exit(0);
                default:
                    puts("Invalid choice!");
                    break;
            }
        }
    }
}

int main(void)
{
    init(); // set up program - skip
    banner();  
    vuln();
    return 0;
}